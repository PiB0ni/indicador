let suaidade;
let aventura;
let ação;
let RPG;
let título;
let corpo;
let jogos= {
  menor10: {
    ação: "Sonic Mania",
    aventura: "Minecraft",
    RPG: "Pokémon"
  }, 
  entre10e14:{
    ação: "Batman:Arkhan Knight",
    aventura: "A Hat in time",
    RPG: "Undertale"
  },
  entre14e16: {
    ação: "Hollow Knight",
    aventura: "Red Dead Redemption 2",
    RPG: "Persona 3:RELOAD"
  },
  entre16e18: {
    ação: "Far Cry 5",
    aventura: "The last of us 2",
    RPG: "Dark Souls"
  },
  maior18: {
    ação: "Watch Dogs 2",
    aventura: "Castlevania:Symphony Of The Night",
    RPG: "Elden Ring"
  }
};

let button;

function setup() {
  createCanvas(850, 400).position(100,100)
  createSpan("Qual sua idade?").position(670,530).addClass("hidden");
  suaidade=createInput("").position(630,585).addClass("hidden");
  ação= createCheckbox("Gosta de jogos de ação?🕹").position(100,600).addClass("hidden");
  aventura= createCheckbox("Gosta de jogos de aventura?⛏").position(100,650).addClass("hidden");
  RPG= createCheckbox("Gosta de jogos de RPG?🎲").position(100,700).addClass("hidden");
título= "Pacifico";
  corpo = "Oswald";
  button = createButton("NEW GAME👁").position(width/2,560);
  button.mousePressed(bota);
  button.addClass("botao");
}

function bota(){
  selectAll(".hidden").forEach((el) => el.removeClass("hidden"));
button.hide();
}
function draw() {
  background("white");
  fill("black");
  stroke("red")
  textAlign(CENTER,CENTER);
  textSize(40);
  text("Posso te indicar um jogo?", width/2, 25);
  textFont(corpo);
  
  
  let idade= parseInt(suaidade.value());
  let checkação = ação.checked();
  let checkaventura = aventura.checked();
  let checkRPG = RPG.checked();
  let jogo = "insira suas preferências:"
  if (suaidade.value() !== ""){
  jogo = mostrajogo(idade, checkação, checkaventura, checkRPGws  
                    
 }
  fill ("black")
  textAlign(CENTER, CENTER);
  textSize(40);
  text(jogo, width/2, height/2);
  textFont(título);
  
}

  function mostrajogo(idade, checkação, checkaventura, checkRPG){
    if (isNaN(idade)){
      return "idade inválida";
    } else
      if (idade< 5){
        return "Sai daqui pivete"
      } else
        if (idade> 120){
          return "Já foi de comes e bebes, F"
        }
    if(idade >= 5 && idade < 10){
      if (checkação){
        return jogos ["menor10"]["ação"];
      } if (checkaventura){
        return jogos ["menor10"]["aventura"];
      } if (checkRPG){
        return jogos ["menor10"]["RPG"];
      }
    }    else  if(idade >= 10 && idade < 14){
      if (checkação){
        return jogos ["entre10e14"]["ação"];
      } if (checkaventura){
        return jogos ["entre10e14"]["aventura"];
      } if (checkRPG){
        return jogos ["entre10e14"]["RPG"];
      }
    }else if(idade >= 14 && idade < 16){
      if (checkação){
        return jogos ["entre14e16"]["ação"];
      } if (checkaventura){
        return jogos ["entre14e16"]["aventura"];
      } if (checkRPG){
        return jogos ["entre14e16"]["RPG"];
      }
    }else if(idade >= 16 && idade < 18){
      if (checkação){
        return jogos ["entre16e18"]["ação"];
      } if (checkaventura){
        return jogos ["entre16e18"]["aventura"];
      } if (checkRPG){
        return jogos ["entre16e18"]["RPG"];
      }
    } else if(idade > 18){
      if (checkação){
        return jogos ["maior18"]["ação"];
      } if (checkaventura){
        return jogos ["maior18"]["aventura"];
      } if (checkRPG){
        return jogos ["maior18"]["RPG"];
      }
    }            
  }

